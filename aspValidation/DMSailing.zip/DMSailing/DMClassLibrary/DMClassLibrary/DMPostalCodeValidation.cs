﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace DMClassLibrary
{
    public class DMPostalCodeValidation : ValidationAttribute
    {
        //default message in the constructor
        //{0} is replaced by error field name
        public DMPostalCodeValidation()
		:base("{0} is not a valid Canadian Postal Code.")
        {  }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //if input value is null or empty string, allow it as optional field
            if (value == null || value.ToString().Trim() == "")
                return ValidationResult.Success;
            
            //regular expression for canadian postal code
            //allow upper/lower case
            //allow space/without space
            //Canadian Postal codes do not include the letters D, F, I, O, Q or U, and the first position also does not make use of the letters W or Z.
            Regex pattern = new Regex(@"^[^DFIOQUWZdfioquwz]{1}\d{1}[^DFIOQUdfioqu]{1} ?\d{1}[^DFIOQUdfioqu]{1}\d{1}$", RegexOptions.IgnoreCase);
            
            var boolVal = pattern.IsMatch(value.ToString());

            if (pattern.IsMatch(value.ToString()) == false)
            {
                //pattern mismatch, show error
                  return new ValidationResult(FormatErrorMessage(validationContext.DisplayName));
                 //return new ValidationResult(string.Format(DMTranslations.InvalidPostalCode, DMTranslations.postalCode), new[] { "postalCode" });
                
            }
            else
            {
               //pattern matched, show success
               return ValidationResult.Success;
            }
        }
    }
}
