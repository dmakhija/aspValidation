﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DMSailing.Models;


namespace DMSailing.Controllers
{
    public class DMMemberController : Controller
    {
        private sailSQLContext db = new sailSQLContext();

        // set the session language to the one selected by the user
        protected override void Initialize(System.Web.Routing.RequestContext requestContext)
        {
            base.Initialize(requestContext);
            DMTranslateController.SetLanguage(Request.Cookies);
        }

        //
        // GET: /DMMember/
        //shows all members listing
        public ActionResult Index()
        {
            //TempData["message"] = "Hello";
            var members = db.members.Include(m => m.province);
            return View(members.ToList());
        }

        //
        // GET: /DMMember/Details/5
        //shows details of selected member id
        public ActionResult Details(int id = 0)
        {
            member member = db.members.Find(id);
            if (member == null)
            {
                return HttpNotFound();
            }
            return View(member);
        }

        //
        // GET: /DMMember/Create
        // provides create page to add new member
        public ActionResult Create()
        {
            ViewBag.provinceCode = new SelectList(db.provinces, "provinceCode", "name");
            return View();
        }

        //
        // POST: /DMMember/Create
        // validates and saves new member record to the database
        [HttpPost]
        public ActionResult Create(member member)
        {
            if (ModelState.IsValid)
            {
                try
                {                    
                    db.members.Add(member);
                    db.SaveChanges();
                    TempData["message"] = "New member record added successfully.";
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "error on inserting member: " + ex.GetBaseException().Message);
                    //throw;
                }                
            }

            ViewBag.provinceCode = new SelectList(db.provinces, "provinceCode", "name", member.provinceCode);
            return View(member);
        }

        //
        // GET: /DMMember/Edit/5
        //gets edit form to edit member details for selected member id
        public ActionResult Edit(int id = 0)
        {
            member member = db.members.Find(id);
           if (member == null)
            {
                return HttpNotFound();
            }
            ViewBag.provinceCode = new SelectList(db.provinces, "provinceCode", "name", member.provinceCode);
            return View(member);
        }

        //
        // POST: /DMMember/Edit/5
        // validates and updates the member details in the db for selected member id
        [HttpPost]    
        public ActionResult Edit(member member)
        {         
            if (ModelState.IsValid)
            {
                try
                {
                    db.Entry(member).State = EntityState.Modified;
                    db.SaveChanges();
                    TempData["message"] = "Member details updated successfully.";
                   // ViewState["message"] = "Member details updated successfully.";
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "error on updating member: " + ex.GetBaseException().Message);
                    //throw;
                }
                
            }
            ViewBag.provinceCode = new SelectList(db.provinces, "provinceCode", "name", member.provinceCode);
            return View(member);
        }

        //
        // GET: /DMMember/Delete/5
        //gets delete confirmation page for selected member id
        public ActionResult Delete(int id = 0)
        {
            member member = db.members.Find(id);
            if (member == null)
            {
                return HttpNotFound();
            }
            return View(member);
        }

        //
        // POST: /DMMember/Delete/5
        //confirms and deletes the details from db for selected member id
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            member member = db.members.Find(id);
            try
            {                
                db.members.Remove(member);
                db.SaveChanges();
                TempData["message"]="Member record deleted successfully.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["message"] = "Error on deleting member: " + ex.GetBaseException().Message;
                return RedirectToAction("Delete", new{id = member.memberId});
            }
            
        }

        //remote action for province code validation
        public JsonResult IsProvinceCode(String provinceCode)
        {
            if (provinceCode == null || provinceCode.Trim() == "")
            {
                //province code can be optional sometimes
                //if its null, accept it as optional
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                //check if this province code is on file or not
                var isValidProvince = db.provinces.Find(provinceCode);
                if (isValidProvince == null)
                {
                    //return innermost exception as error msg
                    return Json("Province Code Not Found.", JsonRequestBehavior.AllowGet);                    
                }
                else
                {
                    //found valid province, so allow get and post to server
                    return Json(isValidProvince.provinceCode, JsonRequestBehavior.AllowGet);
                }
            }            
        }

        //releases the unneeded resources
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}