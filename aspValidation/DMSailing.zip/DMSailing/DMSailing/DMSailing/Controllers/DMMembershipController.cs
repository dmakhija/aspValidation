﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DMSailing.Models;

namespace DMSailing.Controllers
{
    public class DMMembershipController : Controller
    {
        private sailSQLContext db = new sailSQLContext();

        Int32 memberId = 0;
        string fullName = "";

        //
        // GET: /DMMembership/

        public ActionResult Index()
        {

            if (Request.QueryString["memberId"] != null)
            {
                memberId = Convert.ToInt32(Request.QueryString["memberId"].ToString());
                fullName = Request.QueryString["fullName"].ToString();

                Response.Cookies.Add(new HttpCookie("memberIdCookie", memberId.ToString()));
                Response.Cookies.Add(new HttpCookie("fullNameCookie", fullName));

                Session.Add("memberIdSession", memberId.ToString());
                Session.Add("fullNameSession", fullName);
            }
            else
            {
                if (Request.Cookies["memberIdCookie"].Value != null)
                {
                    memberId = Convert.ToInt32(Request.Cookies["memberIdCookie"].Value);
                    fullName = Request.Cookies["fullNameCookie"].Value;
                }
                else if (Session["memberIdSession"].ToString() != null)
                {
                    memberId = Convert.ToInt32(Session["memberIdSession"].ToString());
                    fullName = Session["fullNamSession"].ToString();
                }
                else
                {
                    TempData["message"] = "Member not selected for membership history.";
                    RedirectToAction("Index", "DMMember");
                }
            }

            ViewBag.memberId = memberId;
            ViewBag.fullName = fullName;

            var memberships = from record in db.memberships
                              where (record.memberId == memberId)
                              orderby record.year descending
                              select record;
            return View(memberships.ToList());
        }

        //
        // GET: /DMMembership/Details/5

        public ActionResult Details(int id = 0)
        {
            membership membership = db.memberships.Find(id);
            if (membership == null)
            {
                return HttpNotFound();
            }
            return View(membership);
        }

        //
        // GET: /DMMembership/Create

        public ActionResult Create()
        {
            ViewBag.memberId = new SelectList(db.members, "memberId", "fullName");
            ViewBag.membershipTypeName = new SelectList(db.membershipTypes, "membershipTypeName", "description");
            return View();
        }

        //
        // POST: /DMMembership/Create

        [HttpPost]
        public ActionResult Create(membership membership)
        {
            if (ModelState.IsValid)
            {
                db.memberships.Add(membership);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.memberId = new SelectList(db.members, "memberId", "fullName", membership.memberId);
            ViewBag.membershipTypeName = new SelectList(db.membershipTypes, "membershipTypeName", "description", membership.membershipTypeName);
            return View(membership);
        }

        //
        // GET: /DMMembership/Edit/5

        public ActionResult Edit(int id = 0)
        {
            membership membership = db.memberships.Find(id);
            if (membership == null)
            {
                return HttpNotFound();
            }
            ViewBag.memberId = new SelectList(db.members, "memberId", "fullName", membership.memberId);
            ViewBag.membershipTypeName = new SelectList(db.membershipTypes, "membershipTypeName", "description", membership.membershipTypeName);
            return View(membership);
        }

        //
        // POST: /DMMembership/Edit/5

        [HttpPost]
        public ActionResult Edit(membership membership)
        {
            if (ModelState.IsValid)
            {
                db.Entry(membership).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.memberId = new SelectList(db.members, "memberId", "fullName", membership.memberId);
            ViewBag.membershipTypeName = new SelectList(db.membershipTypes, "membershipTypeName", "description", membership.membershipTypeName);
            return View(membership);
        }

        //
        // GET: /DMMembership/Delete/5

        public ActionResult Delete(int id = 0)
        {
            membership membership = db.memberships.Find(id);
            if (membership == null)
            {
                return HttpNotFound();
            }
            return View(membership);
        }

        //
        // POST: /DMMembership/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            membership membership = db.memberships.Find(id);
            db.memberships.Remove(membership);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}