﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DMSailing.Controllers
{
    public class DMTranslateController : Controller
    {
        //
        // GET: /DMTranslate/
        /// <summary>
        /// Set up a drop-downlist to choose a different language
        /// this is a partial view inserted into an existing view
        /// </summary>
        /// <returns></returns>
        public ActionResult ChooseLanguage()
        {
            SelectListItem en = new SelectListItem() { Text = "English", Value = "en", Selected=true };
            SelectListItem fr = new SelectListItem() { Text = "French", Value = "fr" };
            SelectListItem hin = new SelectListItem() { Text = "Hindi", Value = "hi-IN" };

            SelectList Languages= new SelectList(new SelectListItem[] { en, fr, hin }, "Value", "Text");
            ViewBag.language = Languages;

            return PartialView();
        }

        /// <summary>
        /// Create cookie for selected language and set it as current culture        
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ChooseLanguage(string language = "en")
        {
            if (language == "")
            {
                language = "en";
            }
            Response.Cookies.Add(new HttpCookie("language", language));
            Session.Add("language", language);

            System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(language);
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture(language);

            return ChooseLanguage();
        }

        /// <summary>
        /// this method sets the language to the one stored in a cookie,
        /// if no cookie is found or it expired, default language is set to English 
        /// </summary>
        /// <param name="cookies"></param>
        public static void SetLanguage(System.Web.HttpCookieCollection cookies)
        {
            if (cookies["language"] != null)
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(cookies["language"].Value);
                System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture(cookies["language"].Value);
            }
            else
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en");
                System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en");
            }
        }

    }
}
