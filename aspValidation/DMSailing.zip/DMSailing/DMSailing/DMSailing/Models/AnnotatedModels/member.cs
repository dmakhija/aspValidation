﻿using DMClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using DMSailing.Models;
using DMSailing.App_GlobalResources;
using System.Web.Mvc;

// this is to define and  apply validation annotations and edits to the member model
namespace DMSailing.Models
{
    ///partial class for member model, to which
    ///annotations from a metadata class are applied and which 
    ///includes a validate method
    [MetadataType(typeof(DMMemberMetadata))]
    public partial class member : IValidatableObject
    {
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            //checkCandaPostValue
            if(useCanadaPost!=null)
            {
                //check whether its true or false
                if (useCanadaPost == true)
                {
                    //email is optional
                    //street and city are required
                    if (street == null || street.Trim() == "")
                    {
                        yield return new ValidationResult(
                            String.Format(DMTranslations.Required, DMTranslations.street), new[] { "street" });
                    }
                    if (city == null || city.Trim() == "")
                    {
                        yield return new ValidationResult(
                            String.Format(DMTranslations.Required, DMTranslations.city), new[] { "city" });
                    }

                }
                else
                {
                    //email must be specified
                    if (email == null || email.Trim() == "")
                    {
                        yield return new ValidationResult(
                        String.Format(DMTranslations.Required, DMTranslations.email),
                        new[] { "email" });
                    }                    
                }
            }
                      
            

            //formatPostalCode method
            formatPostalCode();            

           // deriveFullName();
            if (firstName.Trim() != "" && lastName.Trim() != "")
            {
                deriveFullName();
            }
            else
            {
                //member's firstname and lastname are required fields
                yield return new ValidationResult(
                    String.Format(DMTranslations.Required, DMTranslations.firstName, DMTranslations.lastName),
                    new[] { "firstName", "lastName" });
            }            
        }

        public string formatPostalCode()
        {
            var strPostalCode = postalCode.Trim().ToUpper();
            if (strPostalCode.Contains(" "))
            {
                //there is a space between entered postalCode
                //so entered postal code string has 7 characters
                ////no modification needed
            }
            else
            {
                //no space in between, so entered postal code string has 6 characters
                //add a space after 3 characters
                strPostalCode = strPostalCode.Substring(0, 3) + " " + strPostalCode.Substring(3, 3);                
            }
            postalCode = strPostalCode.Trim(); 
            return postalCode;
        }

        public string deriveFullName()
        {
            //member's firstname and lastname provided, so
            //derive member's fullname from given names

            if ((spouseFirstName == null || spouseFirstName.Trim() == "") && (spouseLastName == null || spouseLastName.Trim() == ""))
            {
                //no details of spouse provided
                //so fullname = Tuton, David
                fullName = lastName + ", " + firstName;
            }
            if (spouseFirstName != null && spouseFirstName.Trim() != "")
            {
                //spouse's firstname provided 
                //so check spouse's last name
                if (spouseLastName == null || spouseLastName.Trim() == "")
                {
                    //spouse's lastname not provided
                    //so fullname = Tuton, David & Mary
                    fullName = lastName + "," + firstName + " & " + spouseFirstName;
                }
                else
                {
                    //spouse's lastname provided
                    //check the value of spouse's lastname
                    if (spouseLastName.Trim().ToLower() == lastName.Trim().ToLower())
                    {
                        //spouse's last name and member's last name are same , 
                        //so fullname = Tuton, David & Mary
                        fullName = lastName + ", " + firstName + " & " + spouseFirstName;
                    }
                    else
                    {
                        //spouse's last name and member's last name are different , 
                        //so fullname = Tuton, David & Smith, Mary
                        fullName = lastName + ", " + firstName + " & " + spouseLastName + ", " + spouseFirstName;
                    }
                }
            }
            else
            {
                //spouse's first name not provided
                //don't worry about spouse's last name
                //so fullname = Turton, David 
                fullName = lastName + ", " + firstName;
            }

            return fullName;
        }
    }

    
    //metadata annotations to be applied to "member" class
    public class DMMemberMetadata 
    {
        [Range(1, 1000)]
        [Display(Name = "memberId", ResourceType = typeof(DMTranslations))]
        [Required(ErrorMessageResourceName="Required", ErrorMessageResourceType=typeof(DMTranslations))]
        public int memberId { get; set; }

        
        [Display(Name = "fullName", ResourceType = typeof(DMTranslations))]
        public string fullName { get; set; }

        //[Required]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(DMTranslations))]
        [Display(Name = "firstName", ResourceType = typeof(DMTranslations))]
        public string firstName { get; set; }

        //[Required]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(DMTranslations))]
        [Display(Name = "lastName", ResourceType = typeof(DMTranslations))]
        public string lastName { get; set; }

        [Display(Name = "spouseFirstName", ResourceType = typeof(DMTranslations))]
        public string spouseFirstName { get; set; }

        [Display(Name = "spouseLastName", ResourceType = typeof(DMTranslations))]
        public string spouseLastName { get; set; }

        [Display(Name = "street", ResourceType = typeof(DMTranslations))]
        public string street { get; set; }

        [Display(Name = "city", ResourceType = typeof(DMTranslations))]
        public string city { get; set; }

        [Display(Name = "provinceCode", ResourceType = typeof(DMTranslations))]
        [Required(ErrorMessageResourceName = "Required", 
            ErrorMessageResourceType = typeof(DMTranslations))]
        [Remote("IsProvinceCode", "DMMember")]
        public string provinceCode { get; set; }

        [DMPostalCodeValidation(ErrorMessageResourceType=typeof(DMTranslations), ErrorMessageResourceName="InvalidPostalCode")]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(DMTranslations))]
        [Display(Name = "postalCode", ResourceType = typeof(DMTranslations))]
        public string postalCode { get; set; }

        [RegularExpression(@"^\d{3}-\d{3}-\d{4}$", ErrorMessageResourceName="InvalidPhone", ErrorMessageResourceType=typeof(DMTranslations))]
        [Display(Name = "homePhone", ResourceType = typeof(DMTranslations))]
        public string homePhone { get; set; }

        [DataType(DataType.EmailAddress)]
        [Display(Name = "email", ResourceType = typeof(DMTranslations))]
        public string email { get; set; }

        [Display(Name = "yearJoined", ResourceType = typeof(DMTranslations))]
        public Nullable<int> yearJoined { get; set; }

        [DataType(DataType.MultilineText)]
        [Display(Name = "comment", ResourceType = typeof(DMTranslations))]
        public string comment { get; set; }

        [Display(Name = "taskExempt", ResourceType = typeof(DMTranslations))]
        public Nullable<bool> taskExempt { get; set; }

        [Display(Name = "useCanadaPost", ResourceType = typeof(DMTranslations))]
        public Nullable<bool> useCanadaPost { get; set; }
                
    }

}